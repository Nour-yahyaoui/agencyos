#!/usr/bin/env bash
# Vercel build step.
#
# Normal path (git integration or `vercel deploy` from this folder): the sources are already
# present, so this only generates the Prisma client.
#
# Connector path: the Arena Vercel connector can only upload a handful of files per call, so
# the deployment is created with package.json + vercel.json + this script and the source tree
# is fetched as a checksum-pinned archive. The archive is byte-identical to this folder.
set -euo pipefail

if [ ! -f prisma/schema.prisma ]; then
  : "${AGENCYOS_SOURCE_URL:?AGENCYOS_SOURCE_URL must point at the source archive}"
  : "${AGENCYOS_SOURCE_SHA256:?AGENCYOS_SOURCE_SHA256 must pin the archive}"
  echo "Fetching source archive…"
  curl -fsSL "$AGENCYOS_SOURCE_URL" -o /tmp/agencyos-src.tar.gz
  echo "${AGENCYOS_SOURCE_SHA256}  /tmp/agencyos-src.tar.gz" | sha256sum -c -
  tar -xzf /tmp/agencyos-src.tar.gz -C .
fi

npx prisma generate --schema prisma/schema.prisma
